# Manage File Processing


## Description:

This service will allow you to replace the file content with desired string.

### Build:
mvn:clean:
mvn:install

### Deploy :
mvn spring-boot:run

## Pre-requisite

- Java 11
- Maven
- Eclispse IDE

## Steps to run the application

- Unzip the application and use above mentioned maven command to build 
- This will create fat Jar file in target folder .
- once its successfully build run command `mvn spring-boot: run` that will start the application.

Now application is up and running
- Please create file(demo.txt) under the file location C:\Test\
- Open Browser and copy /paste the below URL:
- GET : http://localhost:8081/api/replace/{findWord}/{ReplaceWord} - Its not secure app (So please use only http)

#### Description:

- After hitting the about end point on Browser with provided words , you will be getting result of updated file content. 

