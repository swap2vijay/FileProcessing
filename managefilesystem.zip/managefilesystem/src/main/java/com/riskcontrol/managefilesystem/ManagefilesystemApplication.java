package com.riskcontrol.managefilesystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ManagefilesystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(ManagefilesystemApplication.class, args);
	}

}
