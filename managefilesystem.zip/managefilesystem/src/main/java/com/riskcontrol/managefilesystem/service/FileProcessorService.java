package com.riskcontrol.managefilesystem.service;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

@Service
public class FileProcessorService {
	
	@Value("${file.path}")
	String filepath;
	
	public ResponseEntity<List<String>> fileProcessing(String findWord, String replaceWord) {
		List<String> fileResult = null;
		try {
			Path path = Paths.get(filepath);
			boolean result = Files.lines(path).anyMatch(s -> s.contains(findWord));
			if (result) {
				Stream<String> lines = Files.lines(path);
				fileResult = lines.map(line -> line.replaceAll(findWord, replaceWord)).collect(Collectors.toList());
				fileResult.stream().forEach(System.out::println);
				Files.write(path, fileResult);
				lines.close();
			} else {
				fileResult = new ArrayList<String>();
				fileResult.add("Given word is not found in the file");
				return new ResponseEntity<>(fileResult, HttpStatus.NOT_FOUND);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		return new ResponseEntity<>(fileResult, HttpStatus.OK);
	}
}
