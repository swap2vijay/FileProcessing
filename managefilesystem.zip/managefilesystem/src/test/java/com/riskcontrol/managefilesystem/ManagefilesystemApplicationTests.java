package com.riskcontrol.managefilesystem;

import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.ResponseEntity;

import com.riskcontrol.managefilesystem.service.FileProcessorService;

@SpringBootTest
class ManagefilesystemApplicationTests {

	@Autowired
	FileProcessorService fileProcessorService;

	@Test
	void testFileProcessing() {

		List<String> fileContentMock = new ArrayList<String>();
		fileContentMock.add("NoRisk");

		ResponseEntity<List<String>> response = fileProcessorService.fileProcessing("Risk", "NoRisk");

		List<String> fileContent = response.getBody();
		assertTrue(fileContentMock.containsAll(fileContent));

	}

}
